#include <iostream>
#include "functions.h"
int main(){
    print_hello();
    std::cout<<"Factorial is "<< factorial(5)<<std::endl;
    squareroot(9);
}
