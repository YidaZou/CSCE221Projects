#include <iostream>   
using namespace std;
int squareroot(int n)
{
  double param, result;
  param = n;
  result = sqrt(param);
  cout<<"Square root of "<<param<<"(sqrt("<<param<<")):"<<result<<endl; 
  return 0;
}
